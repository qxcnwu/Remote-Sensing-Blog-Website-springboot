# -*- coding: utf-8 -*-
# @Time    : 2022/6/23 23:08
# @Author  : qxcnwu
# @FileName: test.py
# @Software: PyCharm
import json
import os

import imageio
import numpy as np
import pandas as pd
from PIL import Image
from sklearn import metrics
from sklearn.cluster import KMeans
from tqdm import tqdm


def loss(array, y_predict):
    return metrics.silhouette_score(array, y_predict)


def loss_ch(array, y_predict):
    return metrics.calinski_harabasz_score(array, y_predict)


def kmeans(array: np.array, classnum: int):
    """
    对每个不同的类型数量进行聚类
    Args:
        array: 日期，经度，纬度
        classnum: 类型数量
    Returns: [预测结果，聚类中心，迭代次数，轮廓系数]
    """
    data_out = None
    cluster_centers = None
    inertia_ = None
    sc = 0
    for j in range(2, classnum + 1):
        k_means = KMeans(n_clusters=j, random_state=1000)
        k_means.fit(array)
        y_predict = k_means.predict(array)
        data = np.hstack([array, np.expand_dims(y_predict, axis=-1)])
        lossed = loss(array, y_predict)
        lossch = loss_ch(array, y_predict)
        if lossed + lossch > sc:
            sc = lossed + lossch
            sh = lossch
            data_out = data
            cluster_centers = k_means.cluster_centers_
            inertia_ = k_means.inertia_



    return [data_out, cluster_centers, inertia_, sc - sh, sh]


def iters(data: np.array) -> np.array:
    index = np.where(data == 1)
    classname = 2
    down = np.zeros(data.shape)
    answer = np.copy(data)
    answer[answer == 1] = 0
    for i, j in zip(index[0], index[1]):
        if down[i, j] == 1:
            continue
        BFS(i, j, classname, data, down, answer)
        classname = classname + 1
    return answer, classname - 2


def BFS(x: int, y: int, classname: int, data: np.array, down: np.array, answer: np.array):
    """
    广度优先搜索
    :param x: x hang
    :param y: y lie
    :param classname: 代际,编号
    :param data:原始矩阵
    :param down:完成矩阵
    :param answer:答案矩阵
    :return:
    """
    # 赋值
    answer[x, y] = classname
    down[x, y] = 1
    # 搜索3X3  搜索周围8个点
    for i in range(-1, 2):
        for j in range(-1, 2):
            newx = x + i
            newy = y + j
            # 满足条件迭代
            if (down[newx, newy] != 1 and data[newx, newy] == 1):
                BFS(newx, newy, classname, data, down, answer)
    return


def draw(array: np.array):
    arr = np.zeros((80, 140))
    arr[array[:, 0], array[:, 1]] = array[:, 2] + 1
    return arr


def comcat_week():
    '''
    汇总每周的事件
    :param data: iters(data: np.array,k:np.int,show:bool=True,)运行出的每周结果
    :param i: 周数
    :return:
    '''
    data = np.load("ygtze_fdcode_2530_80_140.npy")
    cluster = []
    alg_loss = []
    kmean_loss = []
    for i, temp in tqdm(enumerate(data)):
        answer, classnum = iters(temp)
        answer[np.isnan(answer)] = 0
        index = np.where(answer >= 1)
        array = np.vstack([index[0], index[1]]).T
        classnum = int(np.max(answer) - 2)
        if (array.shape[0] != 0 and classnum > 2):
            esList = kmeans(array, classnum)
            try:
                alg_loss.append(loss(array, (answer[index] - 2).squeeze()))
                bfsch=loss_ch(array,(answer[index] - 2).squeeze())
            except:
                alg_loss.append(np.nan)
                bfsch=np.nan
            save_json = {
                "kmeans_data": draw(esList[0]).tolist(),
                "centers": esList[1].tolist(),
                "iter": esList[2],
                "kmeans_loss": esList[3],
                'kmeans_lossch':esList[4],
                "bfs_loss": alg_loss[-1],
                'bfs_lossch':bfsch,
                "bfs_data": answer.tolist()
            }
        else:
            # a=np.where(answer>=1)
            # # # print(a)
            # print('hang',np.mean(a[0]))
            # print('lie',np.mean(a[1]))
            # # print('++++',np.mean(a,axis=0))
            # print('_____',np.mean(a, axis=1))
            save_json = {
                "kmeans_data": np.zeros((80,140)).tolist(),
                "centers": [np.mean(np.where(answer>=1),axis=1).tolist()],
                "iter": np.zeros((1,1)).tolist(),
                "kmeans_loss": np.nan,
                'kmeans_lossch': np.nan,
                "bfs_loss": np.nan,
                'bfs_lossch': np.nan,
                "bfs_data": answer.tolist()
            }
        save_path = r'E:\data\answer\yangtze_river\sapei\julei\answer\alg_kmean\\' + str(i) + '_kmeans.json'

        # import pickle
        with open(save_path, 'w') as fd:
            fd.write(json.dumps(save_json))
            fd.close()
    return


def parse_itor():
    """
    解析json目录下的json文件
    :return:
    """
    json_path = r"E:\data\answer\yangtze_river\sapei\julei\answer\alg_kmean"
    import os
    files = os.listdir(json_path)
    # json全部解析成为kb类
    kbs = []
    for file in tqdm(files):
        path = os.path.join(json_path, file)
        kbs.append(kb(path))
    return kbs


def combinw_picture():
    # 拼接图像
    def combine(image1, image2, idx):
        w, h = image1.size
        neww, newh = w * 2, h
        new_image = Image.new(image1.mode, (neww, newh), color="white")
        new_image.paste(image1, (0, 0, w, h))
        new_image.paste(image2, (w, 0, w * 2, h))
        return new_image

    image_list = []
    path = r"E:\data\answer\yangtze_river\sapei\julei\answer\kmeans"
    path2 = r"E:\data\answer\yangtze_river\sapei\julei\answer\bfs"
    # 制作GIF
    for file in tqdm(os.listdir(path)):
        image1 = Image.open(os.path.join(path, file))
        image2 = Image.open(os.path.join(path2, file.replace("kmeans", "bfs")))
        save_path = r"E:\data\answer\yangtze_river\sapei\julei\answer\combine\\" + file.split("_")[0] + "_combine.jpg"
        new_image = combine(image1, image2, file.split("_")[0])
        new_image.save(save_path)
        image_list.append(imageio.imread(save_path))
    imageio.mimsave(r"E:\data\answer\yangtze_river\sapei\julei\answer\answer.gif", image_list, 'GIF', duration=0.3)
    return


def make_gif():
    image_list = []
    for i in tqdm(range(2526)):
        path = r"E:\data\answer\yangtze_river\sapei\julei\answer\combine\\" + str(i) + "_combine.jpg"
        if (os.path.exists(path)):
            image_list.append(imageio.imread(path))
    imageio.mimsave(r"E:\data\answer\yangtze_river\sapei\julei\answer\answer.gif", image_list, 'GIF', duration=0.3)
    return


class kb:
    def __init__(self, json_path):
        """
            "kmeans_data": kmeans结果
            "centers": 聚类中心
            "iter": 迭代
            "kmeans_loss": 轮廓系数
            "kmeans_lossch": ch系数
            "bfs_loss":轮廓系数
            "bfs_lossch":ch系数
            "bfs_data":bfs结果
        """
        self.json_path = json_path
        self.kmeans_data = None
        self.centers = None
        self.iter = None
        self.kmeans_loss = None
        self.kmeans_lossch = None
        self.bfs_loss = None
        self.bfs_lossch = None
        self.bfs_data = None
        self.name = self.json_path.split("\\")[-1].split("_")[0]

        # 执行解析
        self.parse_self()

    def parse_self(self):
        """
        解析json文件
        :return:
        """
        with open(self.json_path, "r") as fd:
            temp = json.load(fd)
        fd.close()
        # 属性自动注入 类高级知识
        for i in temp.keys():
            self.__setattr__(i, temp.get(i))
        self.kmeans_data = np.array(self.kmeans_data)
        self.bfs_data = np.array(self.bfs_data)
        self.centers = np.array(self.centers)
        return

    def draw_kmeans(self, path):
        """
        保存kmeans图像
        :param path:
        :return:
        """
        import matplotlib.pyplot as plt
        plt.title(self.name + "_kmeans")
        plt.imshow(self.kmeans_data)
        plt.savefig(path + "/" + self.name + "_kmeans.jpg")
        plt.close()
        return

    def draw_bfs(self, path):
        """
        bfs图像保存
        :param path:
        :return:
        """
        import matplotlib.pyplot as plt
        plt.imshow(self.bfs_data)
        plt.title(self.name + "_bfs")
        plt.savefig(path + "/" + self.name + "_bfs.jpg")
        plt.close()
        return

    def getloss(self):
        """
        获取两个方法的误差差值
        :return:
        """
        return self.kmeans_loss - self.bfs_loss,self.kmeans_lossch - self.bfs_lossch


def main():
    # 聚类计算
    comcat_week()
    # 图像保存路径
    kmeans_pic_path = r"E:\data\answer\yangtze_river\sapei\julei\answer\kmeans"
    bfs_pic_path = r"E:\data\answer\yangtze_river\sapei\julei\answer\bfs"
    # 解析json文件
    kbs = parse_itor()
    # 绘制图像功能在kb类当中
    for k in tqdm(kbs):
        k.draw_kmeans(kmeans_pic_path);
        k.draw_bfs(bfs_pic_path);
    # 绘制对比图象动图
    combinw_picture()
    return


if __name__ == '__main__':
    # main()
    # comcat_week()
    ans = parse_itor()
    # make_gif()
    bfsloss = []
    kmeanlos = []
    bfslossch = []
    kmeanlossch = []
    centers=[]
    for i in ans:
        bfsloss.append(i.bfs_loss)
        kmeanlos.append(i.kmeans_loss)
        bfslossch.append(i.bfs_lossch)
        kmeanlossch.append(i.kmeans_lossch)
        centers.append(i.centers)

    answer=np.zeros([1,3])
    temp=[]
    for indx,i in enumerate(centers):
        if i.shape[1]!=2:
            # print(i)
            temp.append(i)
            continue

        else:
            idx=np.ones([i.shape[0],1])*indx
            i=np.hstack([i,idx])

            answer=np.vstack([answer,i])

    # delete answer`s nan
    nanind=np.where(np.isnan(answer[:,0]))[0]
    answer=np.delete(answer,nanind,axis=0)

    # save centers
    # np.save(r'E:\data\answer\yangtze_river\sapei\julei\answer\center_kmeans\centers_kmeans.npy',answer)

    data_out, cluster_centers, inertia_, sc_sh, sh=kmeans(answer, 160)
    # 拼接评价指标
    a = np.vstack([np.array(bfsloss), np.array(kmeanlos),np.array(bfslossch), np.array(kmeanlossch)]).T
    # pd.DataFrame(a).to_csv(r"E:\data\answer\yangtze_river\sapei\julei\al_km.csv")
    print('over')
