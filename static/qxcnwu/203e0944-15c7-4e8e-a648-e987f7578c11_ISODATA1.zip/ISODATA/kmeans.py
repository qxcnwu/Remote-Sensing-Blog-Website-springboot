# -*- coding: utf-8 -*-
# @Time    : 2022/6/23 18:27
# @Author  : qxcnwu
# @FileName: kmeans.py
# @Software: PyCharm

import numpy as np
from sklearn.cluster import KMeans
from sklearn.cluster import DBSCAN
from sklearn import metrics
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from tqdm import tqdm

def loss(array,y_predict):
    return -metrics.davies_bouldin_score(array, y_predict) \
    +metrics.calinski_harabasz_score(array, y_predict)/10000 \
    +metrics.silhouette_score(array, y_predict)

def kmeans(array:np.array,classnum:int):
    """
    对每个不同的类型数量进行聚类
    Args:
        array: 日期，经度，纬度
        classnum: 类型数量
    Returns: [预测结果，聚类中心，迭代次数，轮廓系数]
    """
    k_means = KMeans(n_clusters=classnum, random_state=1000)
    k_means.fit(array)
    fig = plt.figure(dpi=128,figsize=(8,8))
    ax = fig.add_subplot(111, projection='3d')
    y_predict = k_means.predict(array)
    data=np.hstack([array,np.expand_dims(y_predict,axis=-1)])
    ax.scatter(array[:,0],array[:,2],array[:,1], s=5, cmap="jet", marker="o", c=y_predict)
    plt.savefig("pix/"+str(classnum)+".jpg")
    plt.close(fig)
    return [data,k_means.cluster_centers_,k_means.inertia_,loss(array,y_predict)]

def Dbscan(array:np.array,classnum:int):
    """
    对每个不同的类型数量进行聚类
    Args:
        array: 日期，经度，纬度
        classnum: 类型数量
    Returns: [预测结果，聚类中心，迭代次数]
    """
    db = DBSCAN(eps=1, min_samples=5,n_jobs=-1)
    features = StandardScaler().fit_transform(array)  # 将特征进行归一化
    db.fit(features)
    # fig = plt.figure(dpi=128,figsize=(8,8))
    # ax = fig.add_subplot(111, projection='3d')
    db_labels = db.labels_+1  # 获取聚类之后没一个样本的类别标签
    unique_labels = np.unique(db_labels)  # 获取唯一的类别

    num_clusters = len(unique_labels)
    cluster_centers = db.components_
    data=np.hstack([array,np.expand_dims(db_labels,axis=-1)])
    # plt.title("num of class "+str(num_clusters))
    # ax.scatter(array[:,0],array[:,2],array[:,1], s=5, cmap="jet", marker="o", c=db_labels)
    # plt.savefig("pix/db_labels_"+str(classnum)+".jpg")
    # plt.close(fig)
    return [data,cluster_centers,num_clusters]

def main():
    data = np.load("ygtze_fdcode_2530_80_140.npy")
    data[np.isnan(data)]=0
    index=np.where(data>=1)
    array = np.vstack([index[2], index[0], index[1]]).T
    min_size=-10000
    temp_list=[]
    for i in tqdm(range(2,50)):
        ansList=kmeans(array,i)
        if ansList[3]>min_size:
            print(ansList[3])
            min_size=ansList[3]
            temp_list=ansList
    return temp_list

def maindb():
    ans=[]
    a=1
    data = np.load("ygtze_fdcode_2530_80_140.npy")
    data[np.isnan(data)] = 0
    center=[]
    for i in tqdm(range(2536//a)):
        try:
            arrays = data[i]
            index=np.where(arrays>=1)
            array = np.vstack([index[0], index[1]]).T
            temp=Dbscan(array,i)
            center.append(temp[1])
            ans.append(temp)
        except:
            pass
    return ans,center


if __name__ == '__main__':
    # temp_list=main()
    a,c=maindb()
    b=0
    for i in a:
        b+=i[2]

    # 国产卫星
    # 定量遥感
    # 云平台 + 一体化 + -> 网页 + 手机+APP
    # 博客 + 云服务云计算 + 手机端 + 云同步
    # 高分 + 吉林一号