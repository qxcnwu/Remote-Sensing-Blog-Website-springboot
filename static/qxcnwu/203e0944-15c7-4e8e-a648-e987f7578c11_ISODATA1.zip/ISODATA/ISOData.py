# -*- coding: utf-8 -*-
# @Time    : 2022/6/23 12:41
# @Author  : qxcnwu
# @FileName: ISOData.py
# @Software: PyCharm

"""
输入：一系列的行列号 [[1,1],[2,3],[5,7]...[xn,yn]]
输出：每个点对应的类别
"""

from typing import List

import imageio
import matplotlib.pyplot as plt
import numpy as np


class ISODATA:
    def __init__(self, points: List[List[int]],
                 K: int, thetaN: int = 21, thetaS: float = None
                 , thetaC: float = 50, L: int = 3, I: int = 100):
        """
        初始化ISODATA对象
        Args:
            points: 输入的N个样本
            K: 预期的聚类中心数量 结果=[K/2,K*2]
            thetaN: 每一个事件的最少的格子数量，限制面积
            thetaS: 一个事件中各个点到聚类中心距离的标准差
            thetaC: 两个事件聚类中心的最小距离
            L: 再一次迭代中能够将多少个小范围事件合并成一个大的事件
            I: 运算次数
        """
        self.I = I
        self.L = L
        self.thetaC = thetaC
        self.thetaS = thetaS
        self.thetaN = thetaN
        self.K = K
        self.points = np.array(points)

        # 初始化标签，每个点对应的类别编号是0
        self.label = np.zeros(len(points))

        # 保存所有的聚类中心然后这些聚类中心和类别标签11对应
        # 初始只有一个类别0 他的聚类中心为 [mean(x),mean(y)]
        self.centers = np.array([np.mean(self.points, 0)])
        self.center_num = 1
        self.center_distance = 0

        # 保存中间图像
        self.images = []

    def isodata_update(self):
        """
        第二步：将N个模式样本分给最近的聚类Sj，假若Dj=min{∥x−zi∥,i=1,2,⋯Nc}
           ，即||x−zj||的距离最小，则x∈Sj。
        """
        # 计算每个点到每个聚类中心的距离
        distance = np.zeros((len(self.points), self.center_num))
        delList = []
        for i in range(self.center_num):
            for i in range(self.center_num):
                # 计算距离欧力基德距离
                distance[:, i] = np.sqrt(
                    np.power(self.points[:, 0] - self.centers[i][0], 2) + np.power(self.points[:, 1] - self.centers[i][1],
                                                                                   2))
            # 归并到距离最小的那一类
            self.label = np.argmin(distance, axis=1)
            """
            第四步：修正各聚类中心 zj=1Nj∑x∈Sjx,j=1,2,⋯,Nc
            """
            index = np.where(self.label == i)
            self.centers[i] = np.mean(self.points[index], axis=0)
            if (len(index[0]) <= 0):
                delList.append(i)
        self.centers = np.delete(self.centers, delList, axis=0)
        self.center_num = self.centers.shape[0]
        """
        第五步：计算各聚类域Sj中模式样本与各聚类中心间的平均距离 
               D¯j=1Nj∑x∈Sj∥x−zj∥,j=1,2,⋯,Nc
        """
        distance_temp = 0
        for i in range(self.center_num):
            points = self.points[np.where(self.label == i)]
            temp = np.mean(np.sqrt(
                np.power(points[:, 0] - self.centers[i][0], 2) + np.power(points[:, 1] - self.centers[i][1], 2)))
            distance_temp += temp
        """
        第六步：计算全部模式样本和其对应聚类中心的总平均距离
               D¯=1N∑j=1NNjD¯j
        """
        self.center_distance = distance_temp / self.center_num
        return

    def main(self):
        """
        主函数
        Returns:
        """
        # 初始化
        self.isodata_update()
        self.draw()
        # 循环更新
        for i in (range(self.I)):
            if self.center_num <= self.K // 2:
                self.isodata_divide()
            elif self.center_num > 2 * self.K or (i % 2 == 0 and i > 0):
                self.isodata_combine()
            else:
                self.isodata_divide()
            self.isodata_update()
            self.draw()
        return

    def isodata_divide(self):
        print("开始", self.centers)
        """
        将一个大的聚类拆分为几个小的聚类
        Returns:
        """
        """
        计算S1,S2,...,Sn-1,Sn中的标准差向量
        """
        newcenters = self.centers.copy()
        # 开始遍历所有的聚类类别，判断他们呢是否需要背拆分成为两个更小的类别
        for i in range(self.center_num):
            # 获取属于类别i的所有样本点索引
            index = np.where(self.label == i)
            points = self.points[index]
            # 计算标准差，对于这个标准差 [std(x),std(y)]
            stdMean = np.mean((points - self.centers[i]) ** 2, 0)
            # 寻找标准差最大分量
            maxindex = np.argmax(stdMean)
            maxStd = stdMean[maxindex]
            # 计算样本到样本中心的平均距离
            distance = np.mean(np.sqrt(
                np.power(points[:, 0] - self.centers[i][0], 2) + np.power(points[:, 1] - self.centers[i][1], 2)))
            # 判断是否需要拆分
            if maxStd > self.thetaS and self.center_num <= self.K // 2 or index[0].shape[0] > 2 * (self.thetaN + 1) and \
                    distance >= self.center_distance:
                # 如果进行拆分，那么将源聚类中心，分别加上或者减去1/2最大标准差,
                # 得到两个新的聚类中心，然后将这两个新的聚类中心加入到原始的聚类中心当中
                first = self.centers[i].copy()
                second = self.centers[i].copy()
                print(newcenters,first,second)
                first[maxindex] += 0.5 * maxStd
                second[maxindex] -= 0.5 * maxStd
                print(newcenters,first, second)
                # 删除原来的聚类中心
                newcenters = np.delete(newcenters, i, axis=0)
                # 添加新的聚类中心
                newcenters = np.vstack([newcenters, first, second])

            else:
                continue
        # 全部都更新完成了
        self.centers = newcenters
        self.center_num = self.centers.shape[0]
        print("结束", self.centers)
        return

    def isodata_combine(self):
        """
        讲几个小的聚类合并成为大的聚类
        Returns:
        """
        # 第十一步：计算全部聚类中心的距离
        distance = np.zeros((self.center_num, self.center_num))
        for i in range(self.center_num):
            distance[:, i] = np.sqrt(
                np.power(self.centers[:, 0] - self.centers[i][0], 2) + np.power(
                    self.centers[:, 1] - self.centers[i][1], 2))
        distance += np.eye((self.center_num)) * 100000000
        dellist = []
        while True:
            # 如果有两个中心其距离小于距离阈值，则对他进行合并
            minDist = np.min(distance)
            # 如果所有聚类中心都满足距离条件那么则退出
            if (minDist >= self.thetaC):
                break
            # 反之进行合并
            # index -> [firt,second] firt类别中心和second类别中心靠得太近需要合并成为一个
            temp_index = np.where(np.min(distance) == distance)
            first = temp_index[0][0]
            second = temp_index[1][0]
            dellist.append(first)
            dellist.append(second)
            # 形成新的中心
            """
            第十三步：将距离为Dikjk的两个聚类中心Zik和Zjk合并，得新的中心为：
                    z∗k=1Nik+Njk[Nikzik+Njkzjk],k=1,2,⋯,L
                    式中，被合并的两个聚类中心向量分别以其聚类域内的样本数加权，使Z∗k为真正的平均向量。
            """
            classnumfirst = len(np.where(self.label == first)[0])
            classnumsecond = len(np.where(self.label == second)[0])
            Z = 1 / (classnumfirst + classnumsecond) * (
                    classnumfirst * self.centers[first] + classnumsecond * self.centers[second])
            self.centers = np.vstack([self.centers, Z])
            self.center_num -= 1
            distance[first, :] = float("inf")
            distance[second, :] = float("inf")
            distance[:, first] = float("inf")
            distance[:, second] = float("inf")
        self.centers = np.delete(self.centers, dellist, axis=0)
        self.centerNum = self.centers.shape[0]
        return

    def draw(self):
        plt.title("The " + str(len(self.images)) + " iteros")
        plt.scatter(self.points[:, 0], self.points[:, 1], c=self.label)
        path = "pix/" + str(len(self.images)) + ".jpg"
        plt.savefig(path)
        self.images.append(imageio.imread(path))
        plt.close()
        return


def makegif(name: str, imgs: List[str]):
    imageio.mimsave(name, imgs, fps=5)
    return


if __name__ == '__main__':
    data = np.load("3.npy")
    index = np.where(data == 1)
    temp = np.vstack([index[0], index[1]]).T
    temp[:, 0] = temp[:, 0] + np.random.randn(len(temp))
    temp[:, 1] = temp[:, 1] + np.random.randn(len(temp))
    iso = ISODATA(temp, 5, 10, 1, 200, 1, 50)
    iso.main()
    makegif("5.gif", iso.images)
